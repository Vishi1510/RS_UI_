import { create } from "zustand";

const initialState = {
  pageTitle: [{ name: "", number: null, id: null }],
  count: 0,
};

const interceptor = {
  count: (v) => {
    localStorage.setItem("count", v);
  },
};

export const useStore = create((set) => ({
  ...initialState,
  // generate set functions for each state
  // e.g. setPageTitle, setPageSubtitle, setPageActiveTab
  ...Object.keys(initialState).reduce((acc, key) => {
    acc[`set${key.charAt(0).toUpperCase() + key.slice(1)}`] = (value) => {
      interceptor[key] && interceptor[key](value);
      set({ [key]: value });
    };
    return acc;
  }, {}),
}));
