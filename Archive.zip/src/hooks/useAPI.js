import { useQuery, useMutation } from "react-query";
import request from "services/request";

export const useAPI = () => {
  const query = (url, params = {}, options = {}) =>
    useQuery(
      [url],
      async () => {
        return request({
          url,
          method: "get",
          params: {
            ...(params || {}),
          },
        });
      },
      options
    );
  const mutation = (method, url, options) =>
    useMutation(async (params) => {
      const { pathParam, body, ...restParams } = params;

      return request({
        url: url + (pathParam ? "/" + pathParam : ""),
        method,
        params: restParams,
        data: body,
      });
    }, options);

  return {
    query,
    mutation,
  };
};

// import { useQuery, useMutation } from "react-query";
// import request from "services/request";

// export const useAPI = (url, data = {}, options = {}) => {
//   return useQuery(
//     [url, JSON.stringify(data)],
//     () =>
//       request({
//         url,
//         // method: 'POST',
//         data,
//       }),
//     options
//   );
// };
