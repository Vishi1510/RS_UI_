import { createBrowserRouter, Navigate } from "react-router-dom";

import DefaultLayout from "./layouts/default";
import Insights from "./pages/insights";
import Landing from "./pages/landing";

export const routes = createBrowserRouter([
  {
    path: "/",
    element: <DefaultLayout />,
    children: [
      {
        path: "/",
        title: "Home Page",
        element: <Navigate to="/landing" />,
      },
      {
        path: "insights",
        title: "Insights",
        children: [
          {
            path: ":category?",
            title: "My Portfolio",
            element: <Insights />,
            children: [
              {
                path: ":insightId?",
                title: "My Portfolio",
                element: <Insights />,
              },
            ],
          },
        ],
      },
    ],
    errorElement: <div />,
  },
  {
    path: "landing",
    title: "Landing",
    element: <Landing />,
  },
]);
