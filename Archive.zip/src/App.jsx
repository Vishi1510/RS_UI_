import { RouterProvider } from "react-router-dom";
import { routes } from "./routes.jsx";

import { QueryClient, QueryClientProvider } from "react-query";

import { ConfigProvider, Spin } from "antd";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      refetchOnmount: false,
      refetchOnReconnect: false,
      retry: false,
      staleTime: 5 * 60 * 1000,
      // refetchInterval: 10000,
    },
  },
});

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <ConfigProvider
        button={{
          style: {
            boxShadow: "none",
          },
        }}
        theme={{
          token: {
            colorPrimary: "#1D3544",
            borderRadius: 6,
            fontFamily: "Helvetica Neue Roman",
            fontSizeBase: 14,
            motionUnit: 0.2,
            colorTextBase: "#1D3544",
            colorTextLightSolid: "#fff",
            colorError: "#D03A50",
            colorErrorBg: "#FDF2F2",
            colorErrorBorder: "#FDF2F2",
            colorSuccess: "#55b685",
            colorSuccessBg: "#55b68624",
          },
          components: {
            // Card: {
            //     lineWidth: 0,
            //     colorTextHeading: '#1D3544',
            //     colorTextBase: '#1D3544',
            // },
            // Menu: {
            //     collapsedWidth: 60,
            //     darkItemSelectedBg: '#1d3544',
            // },
            // Layout: {
            //     colorBgLayout: '#eef1f2',
            // },
            // Tag: {
            //     defaultBg: '#EEF1F2',
            //     defaultColor: '#596E7C',
            // },
            // DatePicker: {
            //     cellActiveWithRangeBg: '#dce2e5',
            // },
          },
        }}
      >
        <RouterProvider router={routes} fallbackElement={<Spin spinning />} />
      </ConfigProvider>
    </QueryClientProvider>
  );
};

export default App;
