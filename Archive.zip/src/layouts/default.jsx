import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import { Layout, App as Antapp, Menu, theme } from "antd";
import reedsmith_logo from "/reedsmith.svg"; // Import the image
import icon_insights from "/icon-insights.svg";
import icon_tasks from "/icon-tasks.svg";
import "./styles.css"; // Import the custom CSS

// Extract the components from Layout
const { Header, Sider, Content } = Layout;

// Function to create menu items
function getItem(label, key, icon, children) {
  return {
    key,
    icon,
    children,
    label,
  };
}

// Menu items for the Sider
const items = [
  getItem(
    "Insights",
    "1",
    <img src={icon_insights} alt="Insights" className="icon-red" />
  ),
  getItem(
    "My Tasks",
    "2",
    <img src={icon_tasks} alt="My Tasks" className="icon-grey" />
  ),
];

const DefaultLayout = () => {
  const [collapsed, setCollapsed] = useState(true);
  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  return (
    <Antapp>
      <Layout className="h-screen">
        <Header
          className="flex items-center bg-grey-1 text-white"
          style={{ padding: 0, height: 44 }}
        >
          <img
            src={reedsmith_logo}
            alt="reedsmith_logo"
            className="px-6 py-3"
          />
        </Header>
        <Layout className="sideBar">
          <Sider
            collapsible
            collapsed={collapsed}
            onCollapse={(value) => setCollapsed(value)}
            theme="light"
          >
            <div className="demo-logo-vertical" />
            <Menu
              theme="light"
              defaultSelectedKeys={["1"]}
              mode="inline"
              items={items}
            />
          </Sider>
          <Content className="bg-grey-6 overflow-auto">
            <Outlet />
          </Content>
        </Layout>
      </Layout>
    </Antapp>
  );
};

export default DefaultLayout;
