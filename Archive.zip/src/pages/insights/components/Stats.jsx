import React from "react";

const Stats = ({ title, body }) => {
  const cards = [
    { title: "Insights Generated", body: 0 },
    { title: "Insights Assigned", body: 0 },
    { title: "Insights To Matters", body: 0 },
    { title: "Time Value Created", body: 0 },
  ];

  return (
    <div className=" flex gap-3.5 px-6 pb-6">
      {cards.map((c) => (
        <div
          key={c.title}
          className={`rounded-2xl flex flex-wrap grow gap-3 p-4 bg-white shadow-md`}
        >
          <div className="flex flex-col gap-1">
            <div className="text-sm text-grey-3">{c.title}</div>
            <h2>{c.body}</h2>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Stats;
