import React, { useEffect, useState } from "react";
import { Modal, Select, Input, Button } from "antd";
import { Checkbox } from "antd";
import { useAPI } from "hooks/useAPI";
import { IoCloseOutline } from "react-icons/io5";

const AssignModal = ({
  open,
  onCancel,
  opportunity,
  organization,
  category,
}) => {
  const [options, setOptions] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [searchText, setSearchText] = useState("");
  const { data: fullAssigneeList } = useAPI().query(
    "https://radar-backend-api-with-filtering.azurewebsites.net/assignees/",
    {},
    {
      enabled: open,
    }
  );

  const { data: CRLAssigneeList } = useAPI().query(
    "https://radar-backend-api-with-filtering.azurewebsites.net/assignees_crl/",
    {},
    {
      enabled: open,
    }
  );

  const { data: opportunityAssignments } = useAPI().query(
    "https://radar-backend-api-with-filtering.azurewebsites.net/opportunity-assignments",
    {
      filter: '["opportunity","=",47689]',
      take: 1,
      format: "json",
    },
    {
      enabled: open,
    }
  );

  const { data, mutate } = useAPI().mutation(
    "post",
    "https://reqres.in/api/users"
  );

  const mergedAssigneeList = (CRLAssigneeList?.data || [])
    .reduce(
      (a, c, i) => {
        const found = a.find(
          (i) => i.timekeeper_number === c.timekeeper_number
        );
        return !found ? [...a, c] : a;
      },
      [...(fullAssigneeList?.data || [])]
    )
    .filter((i) => i.practice_grp === category);

  useEffect(() => {
    setSearchText("");
  }, [selectedOptions]);

  useEffect(() => {
    fullAssigneeList?.data &&
      setOptions(
        fullAssigneeList.data.map((item) => ({
          label: item,
          value: item.timekeeper_number,
        }))
      );
  }, [fullAssigneeList]);

  useEffect(() => {
    setOptions(
      (fullAssigneeList?.data || [])
        .map((item) => ({
          label: item,
          value: item.timekeeper_number,
        }))
        .filter((i) =>
          i.label.name.toLowerCase().includes(searchText.toLowerCase())
        )
    );
  }, [searchText]);

  const onSend = () => {
    mutate({
      body: {
        test: 1,
      },
      quesrParam: "test",
      pathParam: 4,
    });
  };

  const renderList = (list) => (
    <div className="px-3 max-h-[200px] overflow-auto">
      {list.map(({ label, value }) => (
        <div
          key={label.timekeeper_number}
          className="flex gap-3 items-center mb-1 hover:bg-blue-6 rounded-full p-1 pr-2 cursor-pointer"
          onClick={() => {
            if (selectedOptions.includes(label.timekeeper_number)) {
              setSelectedOptions(
                selectedOptions.filter((item) => item !== value)
              );
            } else {
              setSelectedOptions([...selectedOptions, value]);
            }
          }}
        >
          <div className="bg-[#C886BF] flex items-center justify-center w-[28px] h-[28px] rounded-full text-white text-sm w-[25px] h-[25px] max-w-[25px] max-h-[25px] min-w-[25px] min-h-[25px]">
            {label.name.slice(0, 1)}
          </div>
          <div className="class=flex gap-1.5 items-center w-[40%]">
            {label.name}
          </div>
          <div className="font-normal w-[50%]">{label.designation}</div>
          <div className="flex-1">
            <div>
              <Checkbox
                checked={selectedOptions.includes(label.timekeeper_number)}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <Modal open={open} onCancel={onCancel} okText="Send" onOk={onSend}>
      <div className="flex flex-col gap-3">
        <div>Assign insights to:</div>
        <div className="flex flex-col gap-3">
          <Select
            disabled={!fullAssigneeList}
            mode="tags"
            value={fullAssigneeList?.data
              .filter((i) => selectedOptions.includes(i.timekeeper_number))
              .map((i) => ({
                label: i,
                value: i.timekeeper_number,
              }))}
            tagRender={(i) => (
              <div class="border-[1px] border-[#BFBFBF] rounded-full px-4 m-1 flex items-center justify-center gap-2">
                <span>{i.label.name}</span>
                <Button
                  type="text"
                  class="text-[#BFBFBF] text-[20px] mx-[-5px]"
                  onClick={() =>
                    setSelectedOptions(
                      selectedOptions.filter((item) => item !== i.value)
                    )
                  }
                >
                  <IoCloseOutline />
                </Button>
              </div>
            )}
            className="w-full"
            placeholder="Search Assignee"
            labelInValue
            //filterOption={false}
            onSearch={(t) => setSearchText(t)}
            searchValue={searchText}
            dropdownRender={() => renderList(options)}
            showSearch
          />
        </div>
        <div>Suggested assignees</div>
        {renderList(
          mergedAssigneeList.map((i) => ({
            label: i,
            value: i.timekeeper_number,
          }))
        )}
        <div className="w-full mb-6">
          <div className="text-sm text-grey-3 mb-2.5">Message</div>
          <Input.TextArea
            rows={3}
            placeholder="Enter a message here..."
            className="w-full border border-grey-4 rounded-md p-2 font-normal mb-3 text-grey-3 focus-visible:border-red outline-none"
          />
        </div>
      </div>
    </Modal>
  );
};

export default AssignModal;
