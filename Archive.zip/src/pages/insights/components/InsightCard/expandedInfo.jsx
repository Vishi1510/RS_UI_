import React, { useState, useEffect } from "react";
import { Modal, Input, Spin } from "antd";
import AssignModal from "./AssignModal";
import { AudioOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { useAPI } from "hooks/useAPI";
import { IoSearchOutline } from "react-icons/io5";
// import "./index.css";

const aplhaOrder = (a, b) => a.localeCompare(b);

const ExpandedInfo = ({ data }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedOrgCategories, setSelectedOrgCategories] = useState(
    data.subcategories.sort(aplhaOrder)
  );
  const [searchInputValue, setSearchInputValue] = useState("");
  const [searchText, setSearchText] = useState("");
  const [selectedOrganization, setSelectedOrganization] = useState(null);

  const category = data.category;
  const subcategories = data.subcategories.sort(aplhaOrder);

  useEffect(() => {
    const to = setTimeout(() => {
      setSearchText(searchInputValue);
    }, 500);
    return () => {
      clearTimeout(to);
    };
  }, [searchInputValue]);

  const { data: organizationsData, isFetching } = useAPI().query(
    "https://radar-backend-api-with-filtering.azurewebsites.net/organizations/"
  );

  const isSingleAssign = [
    "international-arbitration",
    "embedding-laterals",
  ].includes(category);

  const isMultiAssign = [
    "life-sciences-and-health",
    "insurance-recovery",
    "whitespace",
  ].includes(category);

  const categoryColors = {
    "life-sciences-and-health": "#E8F5EC",
    "insurance-recovery": "#E5F1F7",
    whitespace: "#E9EAF2",
    // Add more categories and their colors as needed
  };

  // grouping organisations list data by category
  const nestedOrganizations = (organizationsData?.data || [])
    .reduce((a, c, i) => {
      const found = a.find((i) => i.name === c.category);
      let result;
      const filterFunction = (org) =>
        org.title.toLowerCase().includes(searchText.toLowerCase());
      if (found) {
        result = a.map((i) =>
          i.name === c.category
            ? { ...i, children: [...i.children, c].filter(filterFunction) }
            : i
        );
      } else {
        result = [
          ...a,
          { name: c.category, children: [c].filter(filterFunction) },
        ];
      }
      return result.filter((i) => i.children.length > 0);
    }, [])
    .sort((a, b) => aplhaOrder(a.name, b.name));

  // filtering function for the subcategories
  const filterCategories = (nestedCategory) => {
    return selectedOrgCategories.includes(nestedCategory.name);
  };

  return (
    <div>
      <div style={{ marginBottom: "20px" }}>
        {/* <Modal
          okText="Send"
          > */}
        <AssignModal
          open={modalOpen}
          onCancel={() => {
            setModalOpen(false);
            setSelectedOrganization(null);
          }}
          category={category}
          organization={selectedOrganization}
          opportunityId={data}
        />
        {/* </Modal> */}
      </div>
      {isMultiAssign && (
        <div className="px-6 py-5 flex justify-end flex-col gap-1">
          <div style={{ marginBottom: "10px" }}>
            <div className="flex gap-1.5 flex-wrap pb-6 pt-2">
              {subcategories.map((item, index) => (
                <Button
                  size="small"
                  className="rounded-xl text-sm whitespace-nowrap flex gap-1.5 items-center text-grey-2 px-2 h-[24px]"
                  key={index}
                  style={{
                    backgroundColor: categoryColors[category],
                    opacity: selectedOrgCategories.includes(item) ? 1 : 0.5,
                  }}
                  onClick={() =>
                    setSelectedOrgCategories(
                      selectedOrgCategories.includes(item)
                        ? selectedOrgCategories.filter((i) => i !== item)
                        : [...selectedOrgCategories, item].sort(aplhaOrder)
                    )
                  }
                >
                  {item}
                </Button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: "10px" }}>
            <Input
              prefix={<IoSearchOutline className="opacity-50 text-lg" />}
              placeholder="Search Organizations"
              allowClear
              style={{ width: "100%" }}
              onChange={(e) => setSearchInputValue(e.target.value)}
              value={searchInputValue}
            />
          </div>

          <Spin spinning={isFetching}>
            {nestedOrganizations.filter(filterCategories).map((item, index) => (
              <div key={index}>
                <div className="flex gab-2.5 items-center py-4 text-subtitle text-subtitle-lg font-bold border-b border-grey-4">
                  {item.name}
                </div>
                <div>
                  {item.children.map((children) => (
                    <div
                      key={children.title}
                      className="flex items-center gap-3 border-b border-grey-5 last:border-b-0 py-3"
                    >
                      <div className="flex-1 flex flex-col gap-2">
                        <h2>{children.title}</h2>
                      </div>
                      <div className="bg-black text-white rounded-sm px-3 leading-7 disabled:opacity-50">
                        <button
                          onClick={() => {
                            setModalOpen(true);
                            setSelectedOrganization(children);
                          }}
                        >
                          Assign
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </Spin>
        </div>
      )}
      {isSingleAssign && (
        <div className="h-100 w-full">
          <div className="text-subtitle text-subtitle-lg py-4 border-b border-grey-4">
            Hello123
          </div>
          <div className="flex gap-2.5 my-2 items-start justify-between items-start mt-2">
            Hello
          </div>
          <div className="px-6 py-5 flex justify-end flex-col gap-1">
            <div
              style={{ marginBottom: "10px" }}
              className="flex gap-1.5 flex-wrap pb-6 pt-2"
            >
              <Button
                className="bg-black text-white rounded-sm px-4 py-1 leading-7 disabled:opacity-50 self-end"
                onClick={() => setModalOpen(true)}
              >
                Assign
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpandedInfo;
