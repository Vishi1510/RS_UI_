import { Card, Tooltip } from "antd";
import React, { useState } from "react";
import ExpandedInfo from "./expandedInfo";
import { BsBookmark } from "react-icons/bs";
import { TbTrash } from "react-icons/tb";
import { MdOutlineMedicalServices } from "react-icons/md";
import { FaRegBuilding } from "react-icons/fa";
import { TbArrowsExchange } from "react-icons/tb";
import { PiWaves } from "react-icons/pi";
import { SiChase } from "react-icons/si";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
dayjs.extend(relativeTime);

const InsightCard = ({ data = {}, onClick, expanded }) => {
  const [isDeleting, setIsDeleting] = useState(false);

  const categoryMapping = {
    "life-sciences-and-health": {
      icon: <MdOutlineMedicalServices />,
      color: "#1E9F48",
      title_block: "Notice",
      title_color: "#E8F5EC",
      meta_keys: ["source", "agency"],
    },
    "embedding-laterals": {
      icon: <TbArrowsExchange />,
      color: "#E5B522",
      title_block: "Valuable Connection Detected",
      title_color: "#FDF8E8",
      meta_keys: ["Client", "Work Type", "Matter Partner"],
    },
    "international-arbitration": {
      icon: <FaRegBuilding />,
      color: "#E76D25",
      title_block: "Construction Project at Risk",
      title_color: "#FDF0E8",
      meta_keys: ["source", "developer"],
    },
    "insurance-recovery": {
      icon: <PiWaves />,
      color: "#0373AC",
      title_block: "Natural Disaster Detected",
      title_color: "#E5F1F7",
      meta_keys: ["source", "declared on", "affected", "affected", "affected"],
    },
    whitespace: {
      icon: <SiChase />,
      color: "#283584",
      title_block: "Cross-selling Opportunity",
      title_color: "#E9EAF2",
      meta_keys: [
        "Client Relationship Lawyer",
        "Client Industry",
        "Reed Smith Services Utilised",
        "Recommended Practice & Industry Groups",
      ],
    },
  };

  // Here we're mapping each meta items in the data item
  const metaInfo = data.meta
    .filter((meta) =>
      categoryMapping[data.category]?.meta_keys.includes(meta.key)
    )
    .sort((a, b) => {
      categoryMapping[data.category]?.meta_keys.indexOf(a.key) -
        categoryMapping[data.category]?.meta_keys.indexOf(b.key);
    })
    .map((meta) => (
      <div key={meta.key} className="meta-item">
        <div className="text-subtitle text-grey-3 whitespace-nowrap">
          {meta.key}
        </div>
        <div className="leading-4 mt-2 line-clamp-4">{meta.value}</div>
      </div>
    ));

  return (
    <div
      className={`rounded-2xl p-6 mb-6 bg-white shadow-card-selected transition-all`}
      onClick={onClick}
    >
      <div className="flex gap-4 items-start mb-4">
        <div className="flex gap-4 flex-1">
          <div
            className="flex items-center justify-center rounded-full w-[44px] h-[44px] text-white text-lg"
            style={{
              background: categoryMapping[data.category]?.color,
            }}
          >
            {categoryMapping[data.category]?.icon}
          </div>
          <div className="flex-1 items-start">
            <div className="flex justify-between">
              <div
                className="rounded-sm text-sm px-1.5 py-1 mb-2.5 inline-block bg-tint-green"
                style={{
                  background: categoryMapping[data.category]?.title_color,
                }}
              >
                {categoryMapping[data.category]?.title_block}
              </div>
              <div className="flex items-center">
                <div className="text-sm text-grey-3 font-normal mr-4">
                  <Tooltip title={dayjs(data.date).format("DD MMM YYYY")}>
                    {dayjs(data.date).fromNow()}
                  </Tooltip>
                </div>
                <button className="w-[27px] h-[27px] border border-transparent flex items-center justify-center rounded-full transition-all hover:border-yellow hover:bg-tint-yellow ">
                  <BsBookmark style={{ color: "#E5B522" }} />
                </button>
                <button
                  className="w-[27px] h-[27px] border border-transparent flex items-center justify-center rounded-full transition-all hover:border-red hover:bg-tint-red"
                  onClick={() => setIsDeleting(!isDeleting)}
                >
                  <TbTrash size={17} strokeWidth={1.5} color="#CC092F" />
                </button>
              </div>
            </div>
            <h1 className="leading-6 pr-6">{data.title}</h1>
          </div>
        </div>
      </div>
      <div className={expanded ? "h-[calc(100vh-250px)] overflow-auto" : ""}>
        <div className="pt-4 border-grey-5 border-t ">
          <div className="insight-meta flex gap-9 pb-4 mb-4 border-grey-5 border-b life-sciences-and-health">
            {metaInfo}
          </div>
          <div className={`${expanded ? "" : "line-clamp-2"} text-grey-3`}>
            {data.description}
          </div>
          <div
            className={`overflow-hidden transition-all duration-500 ${
              isDeleting ? "h-[200px]" : "h-0"
            }`}
          >
            <div className="bg-tint-red mt-[30px] p-6 rounded-2xl">
              <div className="text-subtitle text-grey-3 mb-3">
                Select one to proceed
              </div>
              {[
                "Not relevant to me",
                "Not enough information subcategories",
                "I don't have time",
                "Other",
              ].map((label) => (
                <div key={label} className="flex items-center gap-1.5">
                  <input
                    id={`${label} summary 235616`}
                    type="radio"
                    name="dismiss-reasons-235616"
                  />
                  <label
                    htmlFor={`${label} summary 235616`}
                    className="font-normal text-grey-3 cursor-pointer"
                  >
                    {label}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
        {expanded && <ExpandedInfo data={data} />}{" "}
      </div>
    </div>
  );
};

export default InsightCard;
