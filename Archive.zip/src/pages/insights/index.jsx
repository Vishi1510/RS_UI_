import React, { useEffect, useState } from "react";
import { Layout, Button, Modal, Divider, Spin } from "antd";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import Stats from "./components/Stats";
import InsightCard from "./components/InsightCard";
import { useAPI } from "hooks/useAPI";
import { BsBookmark } from "react-icons/bs";
import { TbTrash } from "react-icons/tb";
import { CiCircleCheck } from "react-icons/ci";

const { Header, Sider, Content } = Layout;

const Insights = () => {
  const navigate = useNavigate();
  const { category, insightId } = useParams();
  const [activeCategory, setActiveCategory] = useState(category || "all");

  useEffect(() => {
    if (!category) {
      navigate("/insights/all");
    }
  }, [category, navigate]);

  const { data: opportunitiesData, isFetching } = useAPI().query(
    "https://radar-backend-api-with-filtering.azurewebsites.net/opportunities/"
  );

  const categories = [
    { key: "all", label: "All", color: "#CC092F" },
    {
      key: "life-sciences-and-health",
      label: "Life Sciences And Health",
      color: "#1E9F48",
    },
    {
      key: "insurance-recovery",
      label: "Insurance Recovery",
      color: "#0373AC",
    },
    {
      key: "international-arbitration",
      label: "International Arbitration",
      color: "#E76D25",
    },
    {
      key: "embedding-laterals",
      label: "Embedding Laterals",
      color: "#E5B522",
    },
    {
      key: "whitespace",
      label: "White Space",
      color: "#283584",
    },
  ];

  const handleCategoryClick = (key) => {
    setActiveCategory(key);
    navigate(`/insights/${key}`);
  };

  const filteredOpportunities = (opportunitiesData?.data || []).filter(
    (d) => category === "all" || d.category == category
  );

  return (
    <Layout className="h-[calc(100vh-64px)] min-w-[1000px]">
      <Header className="bg-grey-6 flex items-center">
        <div className="bg-grey-6 flex align-start gap-3">
          {categories.map((c) => (
            <Button
              key={c.key}
              size="small"
              type="primary"
              className={`rounded-full px-6 ${
                activeCategory === c.key ? "active" : ""
              }`}
              style={{
                background: activeCategory === c.key ? c.color : "transparent",
                color: activeCategory === c.key ? "#fff" : c.color,
                border: `1px solid ${c.color}`,
              }}
              onClick={() => handleCategoryClick(c.key)}
            >
              {c.label}
            </Button>
          ))}
        </div>
        <Divider type="vertical" />
      </Header>
      <Layout>
        <Sider
          width={"50%"}
          className="p-6"
          style={{ background: "transparent" }}
        >
          <Stats />

          <div className="flex items-center justify-between gap-1.5 mb-3">
            <div className="flex-1 text-grey-3 font-bold uppercase text-xs">
              {category}
              {opportunitiesData?.data
                ? ` / ${filteredOpportunities.length}`
                : ""}
            </div>
            <div className="flex gap-2">
              <button className="w-auto h-[27px] border border-transparent flex items-center justify-center rounded-full transition-all hover:border-yellow hover:bg-tint-yellow px-2">
                <BsBookmark style={{ color: "#E5B522", marginRight: "4px" }} />
                <span style={{ color: "#E5B522" }}>Save</span>
              </button>
              <button className="w-auto h-[27px] border border-transparent flex items-center justify-center rounded-full transition-all hover:border-red hover:bg-tint-red px-2">
                <TbTrash
                  size={17}
                  strokeWidth={1.9}
                  color="#CC092F"
                  style={{ marginRight: "4px" }}
                />
                <span style={{ color: "#CC092F" }}>Dismissed</span>
              </button>
              <button className="w-auto h-[27px] border border-transparent flex items-center justify-center rounded-full transition-all hover:border-green hover:bg-tint-red px-2">
                <CiCircleCheck
                  size={17}
                  strokeWidth={1.5}
                  color="#1E9F48"
                  style={{ marginRight: "4px" }}
                />
                <span style={{ color: "#1E9F48" }}>Assigned</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 max-h-[calc(100vh-280px)] overflow-auto p">
            {opportunitiesData && !isFetching ? (
              filteredOpportunities.map((d) => (
                <InsightCard
                  key={d.id}
                  data={d}
                  onClick={() => navigate(`/insights/${category}/${d.id}`)}
                />
              ))
            ) : (
              <Spin spinning />
            )}
          </div>
        </Sider>
        <Content>
          {insightId && opportunitiesData ? (
            <InsightCard
              data={opportunitiesData.data.find((d) => d.id === +insightId)}
              expanded
            />
          ) : (
            "No Insight Information"
          )}
        </Content>
      </Layout>
    </Layout>
  );
};

export default Insights;
