import React from "react";
import { useNavigate } from "react-router-dom";

const Header = () => {
  return (
    <header className="bg-black text-white py-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold">Law Firm</h1>
        <nav>
          <a href="#services" className="px-4">
            Services
          </a>
          <a href="#about" className="px-4">
            About
          </a>
          <a href="#contact" className="px-4">
            Contact
          </a>
          <a href="/login" className="px-4">
            Login
          </a>
        </nav>
      </div>
    </header>
  );
};

const Hero = () => {
  const navigate = useNavigate();
  return (
    <section
      className="bg-cover bg-center h-screen"
      style={{
        backgroundImage: "url('https://source.unsplash.com/1600x900/?law')",
      }}
    >
      <div className="bg-black bg-opacity-50 h-full flex flex-col justify-center items-center text-white">
        <h2 className="text-4xl md:text-6xl font-bold mb-4">
          Welcome to Our Law Firm
        </h2>
        <p className="text-xl mb-8">
          Expert legal advice for your personal and business needs
        </p>
        <div
          className="bg-orange-500 cursor-pointer text-white py-2 px-6 rounded hover:bg-orange-600"
          onClick={() => navigate("/insights")}
        >
          Go to Insights
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  return (
    <section id="services" className="py-12 bg-gray-100">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-bold mb-6">Our Services</h2>
        <div className="flex flex-wrap justify-center">
          <div className="w-full md:w-1/3 px-4 py-4">
            <div className="bg-white p-6 rounded shadow-lg">
              <h3 className="text-xl font-bold mb-2">Corporate Law</h3>
              <p>
                Expert advice on corporate matters including mergers,
                acquisitions, and compliance.
              </p>
            </div>
          </div>
          <div className="w-full md:w-1/3 px-4 py-4">
            <div className="bg-white p-6 rounded shadow-lg">
              <h3 className="text-xl font-bold mb-2">Family Law</h3>
              <p>
                Compassionate legal support for family-related issues such as
                divorce and custody.
              </p>
            </div>
          </div>
          <div className="w-full md:w-1/3 px-4 py-4">
            <div className="bg-white p-6 rounded shadow-lg">
              <h3 className="text-xl font-bold mb-2">Criminal Defense</h3>
              <p>
                Strong representation to protect your rights in criminal cases.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-12">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-bold mb-6">About Us</h2>
        <p className="text-lg">
          Our law firm has been providing top-notch legal services for over 20
          years. Our team of experienced lawyers is dedicated to ensuring the
          best outcomes for our clients.
        </p>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-12 bg-gray-100">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
        <p className="text-lg mb-4">
          Reach out to us for any legal inquiries or to schedule a consultation.
        </p>
        <p className="text-lg">Email: info@lawfirm.com</p>
        <p className="text-lg">Phone: (123) 456-7890</p>
      </div>
    </section>
  );
};

const Landing = () => {
  return (
    <div className="App bg-[#f1eff5]">
      <Header />
      <Hero />
      <Services />
      <About />
      <Contact />
    </div>
  );
};

export default Landing;
