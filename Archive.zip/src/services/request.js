import axios from "axios";

const devURL = "http://localhost:8000";
const prodURL = "http://localhost:8000";
export const apiUrl = import.meta.env.DEV ? devURL : `${prodURL}`;

export default (options = {}) => {
  options.url = options.url?.includes("http")
    ? options.url
    : `${apiUrl}${options.url}`;
  return new Promise((resolve, reject) => {
    axios({
      mode: "cors",
      cache: "no-cache",
      credentials: "same-origin",
      redirect: "follow",
      referrerPolicy: "no-referrer",
      timeout: 60000,
      headers: {
        Accept: "application/json",
        //Accept: 'text/plain',
        //'Content-Type': 'application/json',
        //'Access-Control-Allow-Methods': 'POST',
        //'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
      ...options,
    })
      .then((r) => resolve(r.data))
      .catch((e) => {
        const errorBody = {
          errorData: {
            code: e.code,
            message: e.message,
          },
          status: e.response?.status,
          statusText: e.response?.statusText,
          data: e.response?.data,
        };

        reject(e.response ? errorBody : e);
      });
  });
};
