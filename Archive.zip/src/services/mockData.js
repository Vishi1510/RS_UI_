export const opportunities = {
  totalCount: 5954,
  data: [
    {
      id: 232440,
      meta: [
        {
          key: "source",
          value: "Federalregister.gov",
        },
        {
          key: "agency",
          value: "Food and Drug Administration",
        },
      ],
      category: "life-sciences-and-health",
      label: "Notice",
      title: "Jessica Palacio; Denial of Hearing; Final Debarment Order",
      description:
        "The Food and Drug Administration (FDA or Agency) is denying a request for a hearing submitted by Andrew S. Feldman, on behalf of Jessica Palacio (Palacio), and is issuing an order under the Federal Food, Drug, and Cosmetic Act (FD&C Act) permanently debarring Palacio from providing services in any capacity to a person that has an approved or pending drug product application. FDA bases this order on a finding that Palacio was convicted of a felony under Federal law for conduct relating to the development or approval, including the process for development or approval, of any drug product under the FD&C Act. FDA provided notice to Palacio of the proposed debarment and an opportunity to request a hearing within the timeframe prescribed by regulation. Palacio submitted a request for hearing but failed to file with the Agency information and analyses sufficient to create a basis for a hearing.",
      date: "2024-05-28",
      data: null,
      subcategories: [
        "Drugs, proprietaries, and sundries",
        "Pharmaceutical preparations",
        "Medical and hospital equipment",
        "Drug stores and proprietary stores",
        "Medical laboratories",
        "Health Care",
        "General medical & surgical hospitals",
        "Specialty outpatient clinics, nec",
        "Specialty hospitals exc. psychiatric",
        "Pharmaceutical products, nec",
        "Biological products exc. diagnostic",
        "Diagnostic substances",
        "Kidney dialysis centers",
      ],
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: false,
      is_dissmissed: null,
      finished_assigned: null,
    },
    {
      id: 232438,
      meta: [
        {
          key: "source",
          value: "Federalregister.gov",
        },
        {
          key: "agency",
          value: "Health Resources and Services Administration",
        },
      ],
      category: "life-sciences-and-health",
      label: "Notice",
      title:
        "Agency Information Collection Activities: Submission to OMB for Review and Approval; Public Comment Request; Implement Maternal, Infant, and Early Childhood Home Visiting Program 2022 Legislative Changes: Assessment of Administrative Burden",
      description:
        "In compliance with the Paperwork Reduction Act of 1995, HRSA submitted an Information Collection Request (ICR) to the Office of Management and Budget (OMB) for review and approval. Comments submitted during the first public review of this ICR will be provided to OMB. OMB will accept further comments from the public during the review and approval period. OMB may act on HRSA's ICR only after the 30-day comment period for this notice has closed.",
      date: "2024-05-28",
      data: null,
      subcategories: [
        "Health Care",
        "General medical & surgical hospitals",
        "Specialty outpatient clinics, nec",
        "Specialty hospitals exc. psychiatric",
        "Medical equipment rental",
      ],
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: null,
      is_dissmissed: null,
      finished_assigned: null,
    },
    {
      id: 222692,
      meta: [
        {
          key: "source",
          value: "NWS",
        },
        {
          key: "declared on",
          value: "2024-05-27",
        },
        {
          key: "affected",
          value: "2 districts",
        },
        {
          key: "affected",
          value: "68 premises",
        },
        {
          key: "affected",
          value: "12 clients",
        },
      ],
      category: "insurance-recovery",
      label: "Natural Disaster Detected",
      title: "NC Alert Severe Thunderstorm Warning",
      description:
        "NC Alert Severe Thunderstorm Warning affected areas include 2 districts and in which 12 of our clients were affected.",
      date: "2024-05-26",
      data: null,
      subcategories: ["Alamance", "Guilford"],
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: null,
      is_dissmissed: null,
      finished_assigned: null,
    },
    {
      id: 222677,
      meta: [
        {
          key: "source",
          value: "NWS",
        },
        {
          key: "declared on",
          value: "2024-05-27",
        },
        {
          key: "affected",
          value: "1 districts",
        },
        {
          key: "affected",
          value: "12 premises",
        },
        {
          key: "affected",
          value: "2 clients",
        },
      ],
      category: "insurance-recovery",
      label: "Natural Disaster Detected",
      title: "KY Alert Severe Thunderstorm Warning",
      description:
        "KY Alert Severe Thunderstorm Warning affected areas include 1 districts and in which 2 of our clients were affected.",
      date: "2024-05-26",
      data: null,
      subcategories: ["Daviess"],
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: null,
      is_dissmissed: null,
      finished_assigned: null,
    },
    {
      id: 4,
      meta: [
        {
          key: "source",
          value: "dubailandregistry.ae/en",
        },
        {
          key: "developer",
          value: "P M R Development L.L.C",
        },
      ],
      category: "international-arbitration",
      label: "Construction Project at Risk",
      title: "The Rings",
      description:
        "Residential building consisting of basement + ground floor + 5 floors + roof\n",
      date: "2024-02-09",
      data: [
        {
          info: [
            {
              key: "Project no.",
              value: "2767",
            },
            {
              key: "Units master project",
              value: "13",
            },
          ],
          title: "Details",
        },
        {
          info: [
            {
              key: "Project value",
              value: "",
            },
            {
              key: "Total lands",
              value: "",
            },
            {
              key: "Total buildings",
              value: "",
            },
            {
              key: "Total villas",
              value: "",
            },
            {
              key: "Total units",
              value: "13",
            },
          ],
          title: "Size",
        },
        {
          info: [
            {
              key: "Project status",
              value: "Active",
            },
            {
              key: "Project started",
              value: "1/20/2024",
            },
            {
              key: "Project due to end",
              value: "12/25/2025",
            },
            {
              key: "Most recent inspection",
              value: "2023-09-21",
            },
            {
              key: "Completed",
              value: "0%",
            },
            {
              key: "Time remaining",
              value: "826, 117.163121 %",
            },
            {
              key: "Total Area (in Sq. Ft)",
              value: "13319.87",
            },
          ],
          title: "Status",
        },
        {
          info: [
            {
              key: "Developer name",
              value: "P M R Development L.L.C",
            },
            {
              key: "Developer number",
              value: "1480",
            },
            {
              key: "Contractor name",
              value: "",
            },
            {
              key: "Contractor number",
              value: "",
            },
          ],
          title: "Parties",
        },
      ],
      subcategories: "",
      propability_of_delay: "LOW",
      is_assigned: false,
      is_pinned: false,
      is_dissmissed: false,
      finished_assigned: false,
    },
    {
      id: 575,
      meta: [
        {
          key: "NAME",
          value: "Richard C. Giller",
        },
        {
          key: "CLIENT_OF_LATERAL",
          value: "Niemann, Jeff",
        },
        {
          key: "MATCHED_INDUSTRY",
          value: " Private Household",
        },
        {
          key: "GROUP",
          value: "Insurance Recovery",
        },
        {
          key: "CLIENT",
          value: "Niemann, Jeff",
        },
        {
          key: "INDUSTRY",
          value: " Private Household",
        },
        {
          key: "RECOMMENDED_GROUP",
          value: "HK Litigation 3",
        },
        {
          key: "TIME_SPENT",
          value: "88549 hours",
        },
        {
          key: "RELEVANT_INDUSTRY",
          value: " Private Household",
        },
      ],
      category: "Embedding Laterals",
      label: "Valuable Connection Detected",
      title: "Connect Richard C. Giller with the HK Litigation 3 group ?",
      description: null,
      date: "2024-02-06",
      data: null,
      subcategories: null,
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: null,
      is_dissmissed: null,
      finished_assigned: null,
    },
    {
      id: 574,
      meta: [
        {
          key: "NAME",
          value: "Richard C. Giller",
        },
        {
          key: "CLIENT_OF_LATERAL",
          value: "Niemann, Jeff",
        },
        {
          key: "MATCHED_INDUSTRY",
          value: " Private Household",
        },
        {
          key: "GROUP",
          value: "Insurance Recovery",
        },
        {
          key: "CLIENT",
          value: "Niemann, Jeff",
        },
        {
          key: "INDUSTRY",
          value: " Private Household",
        },
        {
          key: "RECOMMENDED_GROUP",
          value: "Global Regulatory Enforcement",
        },
        {
          key: "TIME_SPENT",
          value: "182998 hours",
        },
        {
          key: "RELEVANT_INDUSTRY",
          value: " Private Household",
        },
      ],
      category: "Embedding Laterals",
      label: "Valuable Connection Detected",
      title:
        "Connect Richard C. Giller with the Global Regulatory Enforcement group ?",
      description: null,
      date: "2024-02-06",
      data: null,
      subcategories: null,
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: null,
      is_dissmissed: null,
      finished_assigned: null,
    },
    {
      id: 573,
      meta: [
        {
          key: "NAME",
          value: "Richard C. Giller",
        },
        {
          key: "CLIENT_OF_LATERAL",
          value: "Niemann, Jeff",
        },
        {
          key: "MATCHED_INDUSTRY",
          value: " Private Household",
        },
        {
          key: "GROUP",
          value: "Insurance Recovery",
        },
        {
          key: "CLIENT",
          value: "Niemann, Jeff",
        },
        {
          key: "INDUSTRY",
          value: " Private Household",
        },
        {
          key: "RECOMMENDED_GROUP",
          value: "Funds and Investment Management (Inactive 1/2020)",
        },
        {
          key: "TIME_SPENT",
          value: "35456 hours",
        },
        {
          key: "RELEVANT_INDUSTRY",
          value: " Private Household",
        },
      ],
      category: "Embedding Laterals",
      label: "Valuable Connection Detected",
      title:
        "Connect Richard C. Giller with the Funds and Investment Management (Inactive 1/2020) group ?",
      description: null,
      date: "2024-02-06",
      data: null,
      subcategories: null,
      propability_of_delay: null,
      is_assigned: null,
      is_pinned: null,
      is_dissmissed: null,
      finished_assigned: null,
    },
  ],
};
