/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    colors: {
      transparent: "transparent",
      current: "currentColor",
      white: "#ffffff",
      black: "#000000",
      red: "#CC092F",
      green: "#1E9F48",
      orange: "#E76D25",
      yellow: "#E5B522",
      darkYellow: "#C29715",
      blue: {
        1: "#0373AC",
        4: "#9FC8EA",
        6: "#E5F1F7",
      },
      magenta: {
        1: "#92338A",
        6: "#F4EAF3",
      },
      purple: {
        1: "#283584",
        2: "#5C5BA2",
        6: "#E9EAF2",
      },
      tint: {
        red: "#FAE5E9",
        green: "#E8F5EC",
        orange: "#FDF0E8",
        yellow: "#FDF8E8",
      },
      grey: {
        1: "#2D2D2D",
        2: "#333333",
        3: "#666666",
        4: "#BFBFBF",
        5: "#E5E5E5",
        6: "#F4F4F4",
        7: "#F8F8F8",
      },
    },
    fontFamily: {
      sans: ["Helvetica Neue Roman", "sans-serif"],
    },
    fontSize: {
      xs: [
        "9px",
        {
          lineHeight: "9px",
          letterSpacing: "0.2px",
          fontWeight: "500",
        },
      ],
      sm: [
        "11px",
        {
          lineHeight: "12px",
          letterSpacing: "0.2px",
          fontWeight: "500",
        },
      ],
      base: [
        "14px",
        {
          lineHeight: "24px",
          letterSpacing: "0.2px",
          fontWeight: "500",
        },
      ],
      lg: [
        "18px",
        {
          lineHeight: "18px",
          letterSpacing: "0.2px",
          fontWeight: "500",
        },
      ],
    },
    extend: {
      boxShadow: {
        "card-selected": "0px 8px 20px 0px rgba(0, 0, 0, 0.15)",
        "card-unselected": "0px 2px 6px 0px rgba(0, 0, 0, 0.15)",
        "lhm-badge": "0px 2px 5px 0px rgba(73, 0, 0, 0.35)",
        "rhs-scrolling-section":
          "0px 4px 6px 0px rgba(0, 0, 0, 0.08) inset, 0px -4px 6px 0px rgba(0, 0, 0, 0.08) inset",
      },
    },
  },
  plugins: [],
};
